# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) Python Foundations 2

## Student Requirements

Before this lesson, you should be able to work with common Python data types and control flow mechanisms in Jupyter notebooks.

## Learning Objectives

After this lesson, you should be able to perform the following tasks:

- Run basic Python expressions in a REPL.
- Write a simple Python script in a code editor and run it from a terminal on your machine.
- Import objects from installed modules.
- Install additional modules using `conda` and `pip`.
- Work with Python sets.
- Recognize generators and cast them to `list` when appropriate.
- Create list comprehensions.

## Lesson Modules

1. [Python Outside Jupyter](modules/python_outside_jupyter.ipynb)
1. [Python Modules](./modules/python_modules.ipynb)
1. [Sets](./modules/sets.ipynb)
1. [Generators](./modules/generators.ipynb)
1. [List Comprehensions](./modules/list_comprehensions.ipynb)