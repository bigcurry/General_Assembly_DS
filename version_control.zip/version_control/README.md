# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) Version Control

## Learning Objectives

After this lesson, you should be able to...

- Use common Git commands: `init`, `add`, `commit`, `push`, `pull`, and `clone`.
- Distinguish among (1) file directory, (2) staging area, (3) local repository, and (4) remote repository.
- Explain why Git commits are manual and why they are repository-level rather than file-level.
- Fork a GitHub repo and open a pull request from that fork.

## Advanced Track

If you have been working with Git and GitHub regularly for at least a year, have completed all of the prework, and feel comfortable with all of the learning objectives, then you have the option of taking the **advanced track** through this lesson. If you choose the advanced track, then you will be placed in a Zoom breakout room separate from the main session to complete the activities listed below.

If you have a question, look it up and/or discuss it first with the other students in the breakout room. If you aren't able to resolve it, post it on the Slack discussion channel. If you have more than about two or three questions, then you should rejoin the main session, which you may do at any time.

- Complete the exercises in the lesson. Each module has a corresponding solutions notebook in `module_solutions/`. You may refer to the solution notebooks for examples, but do not refer to the exercise solutions until after you have completed the exercise. At that point, use them to check your work.
- Use any time you have left to consult the additional resources given at the bottom of this document or some other command line learning resource.


## Lesson Modules

[Version Control](./modules/version_control.ipynb)

## Recording

[Mar 31, 2020](https://generalassembly.zoom.us/rec/share/uJdPKrvs0FhJHdbRzX3ucI5_IYXbT6a8gyYWqPMJmExjss57qpnCjpJaPa3PF4zp)

## Additional Resources

- Bonus lesson: [Git Branches](https://git.generalassemb.ly/gandenberger-part-time-data-science/git_branches)
- [Try Git - Basic Syntax practice](https://try.github.io/levels/1/challenges/1)
- [Command Line and Git/GitHub Cheat Sheets](https://git.generalassemb.ly/AdiBro/Resources/tree/master/Cheat-Sheets#command-line-and-git)
- [Git and GitHub Resources](https://git.generalassemb.ly/AdiBro/Resources/blob/master/Development-Environment/Git.md)
