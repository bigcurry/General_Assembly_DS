# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) Welcome to Data Science

## Student Requirements

Before this lesson, you should have completed...

- [Prework](https://my.generalassemb.ly/)
- [Installation](https://docs.google.com/document/d/1_LuwDxply5VbLbl3p6rX2BiGjy3wSRzqdXtNSyxw3Ew/edit#)

## Learning Objectives

After this lesson, you should be familiar with course policies and procedures, and you should be able to...

- Define "data science."
- Distinguish among analytics, statistics, and machine learning.
- Explain what is involved in each step of the GA data science workflow.
- Distinguish between supervised and unsupervised learning problems.
- Distinguish between regression and classification problems.
- Distinguish between structured and unstructured data.
- Distinguish between cross-sectional and time-series data.

## Lesson Module

[What Is Data Science?](modules/what_is_data_science.ipynb)

## Recordings

- [Mar 17, 2020](https://generalassembly.zoom.us/rec/share/1cNUCrrJ6D5JWZHO1n3mZ4o6F968T6a8gXAb-aYNnRwFFVIb9C6HC_0c-lQuRhtu)
- [Mar 19, 2020](https://generalassembly.zoom.us/rec/share/_OZFc7arqlFIGYnm6HvABvYFN4Taeaa80XRLr_FfmU8vvgTrxBQFGPBkq7GquP0j)


## Additional Resources

### Fundamental Data Science Concepts

- [Introductory Data Science Concepts](https://en.wikibooks.org/wiki/Data_Science:_An_Introduction)
- [Machine Learning Glossary](https://developers.google.com/machine-learning/glossary/)
- [Why You Shouldn’t Be a Data Science Generalist](https://towardsdatascience.com/why-you-shouldnt-be-a-data-science-generalist-f69ea37cdd2c) -- distinguishes among five different kinds of jobs that are related to data science but require different combinations of skills
- [What Great Data Analysts Do — and Why Every Organization Needs Them](https://hbr.org/2018/12/what-great-data-analysts-do-and-why-every-organization-needs-them) -- on a "sister discipline" to data science
- [What is the question?](https://www.d.umn.edu/~kgilbert/ened5560-1/The%20Research%20Question-2015-Leek-1314-5.pdf) -- gives a flow chart for how to choose the type of analysis that is appropriate to a given problem.
- [Statistical Modeling: The Two Cultures](https://projecteuclid.org/euclid.ss/1009213726) -- early academic paper on the differences between what we would now call statistics and machine learning
- [Data Science Resource List](https://github.com/AdiBro/Data-Science-Resources)

### Data Science Career Resources

Here are some helpful resources about breaking into a career in data science:

- [To get hired as a data scientist, don’t follow the herd](https://towardsdatascience.com/the-economics-of-getting-hired-as-a-data-scientist-e3882933b43c)
- [Quality over quantity: building the perfect data science project](https://towardsdatascience.com/quality-over-quantity-building-the-perfect-data-science-project-993ccc0b1241)
- [The cold start problem: how to build your machine learning portfolio](https://towardsdatascience.com/the-cold-start-problem-how-to-build-your-machine-learning-portfolio-6718b4ae83e9)
- [Why you’re not a job-ready data scientist (yet)](https://towardsdatascience.com/why-youre-not-a-job-ready-data-scientist-yet-1a0d73f15012)

### Statistics Resources

We will be focusing on machine learning rather than statistics in this course. If you would like a practical introduction to statistics, I recommend [Think Stats](https://greenteapress.com/wp/think-stats-2e/).

### General Learning Resources

- [Introduction to Machine Learning for Coders](http://course18.fast.ai/ml) -- the course I recommend as a follow-up after this one.
- [DataCamp Mobile](https://www.datacamp.com/mobile) -- in addition to full-fledged courses, this app provides practice exercises that you can do on a smartphone
- [Anki](https://apps.ankiweb.net/) -- flashcard app that I use every day for programming exercises and anything I want to memorize
