# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) Linear Algebra Foundations

## Learning Objectives

After this lesson, you should be able to...

- Describe at a how level how data science uses linear algebra.
- Computer vector and matrix sums, differences, elementwise products, and dot products by hand and using NumPy.

## Lesson Modules

[Linear Algebra](./modules/linear_algebra.ipynb)

## Recordings

- [Apr 7, 2020](https://generalassembly.zoom.us/rec/share/9J1baKP73ThOUpHQ-kvYY7MPAb7dT6a813AfrPZby03CT0DML7Uw6-JpMClzXIHq)
- [Apr 9, 2020](https://generalassembly.zoom.us/rec/share/yNVfMO3zq2NIfdL2xRndR6khG7rvaaa80CJM_PANmh58_KJz4B79l5_VfXHOGVO-)


## Next Steps

Watch the [first video](https://www.youtube.com/watch?v=fNk_zzaMoSs&list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab&index=2&t=0s) in the *Essence of Linear Algebra* series.

## Additional Resources

- [Essence of Linear Algebra](https://www.youtube.com/playlist?list=PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab) -- incredible video series for developing intuitions about linear algebra.
- [Linear Algebra | Mathematics | MIT Open Courseware](https://ocw.mit.edu/courses/mathematics/18-06-linear-algebra-spring-2010/)
- [Khan Academy Linear Algebra Course](https://www.khanacademy.org/math/linear-algebra)
- [Computational Linear Algebra](https://www.fast.ai/2017/07/17/num-lin-alg/) -- emphasizes how computers do linear algebra
- [Article about resources to learn linear algebra relevant to data science](http://machinelearningmastery.com/linear-algebra-machine-learning/)
- [10 Examples of Linear Algebra in Machine Learning](https://machinelearningmastery.com/examples-of-linear-algebra-in-machine-learning/)
- [Linear Algebra "cheat sheets"](https://git.generalassemb.ly/AdiBro/Resources/tree/master/Cheat-Sheets#linear-algebra) - includes a tutorial called "Linear Algebra in 4 pages" and a SciPy cheat sheet.
- [More Linear Algebra resources](https://github.com/AdiBro/Data-Science-Resources/blob/master/Stats-Math/Math.md#linear-algebra)
