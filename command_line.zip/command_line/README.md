# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) The Command Line

## Learning Objectives

After this lesson, you should be able to...

- Create folders and files using the command line (`mkdir`, `touch`).
- Change directories and list directory content (`cd`, `ls`).
- Check the current working directory (`pwd`).
- Edit and save a file with `vim`.

## Advanced Track

If you have been working in the command line regularly for at least a year, have completed all of the prework, and feel comfortable with all of the learning objectives, then you have the option of taking the **advanced track** through this lesson. If you choose the advanced track, then you will be placed in a Zoom breakout room separate from the main session to complete the activities listed below.

If you have a question, look it up and/or discuss it first with the other students in the breakout room. If you aren't able to resolve it, post it on the Slack discussion channel. If you have more than about two or three questions, then you should rejoin the main session, which you may do at any time.

- Complete the exercises in the lesson. Each module has a corresponding solutions notebook in `module_solutions/`. You may refer to the solution notebooks for examples, but do not refer to the exercise solutions until after you have completed the exercise. At that point, use them to check your work.
- Use any time you have left to consult the additional resources given at the bottom of this document or some other command line learning resource.

## Lesson Modules

[Command Line](./modules/command_line.ipynb)

## Recordings

- [Mar 26, 2020](https://generalassembly.zoom.us/rec/share/7otWDe7b3T1JeKPD00fTBrIjR5nnT6a81nRP8qBcnkxRec0wO8HKEUBBVKMtz04L)
- [Mar 31, 2020](https://generalassembly.zoom.us/rec/share/uJdPKrvs0FhJHdbRzX3ucI5_IYXbT6a8gyYWqPMJmExjss57qpnCjpJaPa3PF4zp)

## Additional Resources

- [Learn Enough Command Line to Be Dangerous](https://www.learnenough.com/command-line-tutorial)
- [Command Line Resources](https://git.generalassemb.ly/AdiBro/Resources/blob/master/Development-Environment/Command-Line.md)
