# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) Git Branches

## Student Requirements

Before this lesson, you should be able to initialize, clone, push, and pull git repositories and create new git commits on a single branch.

## Learning Objectives

After this lesson, you should be able to create and merge git branches both locally and on GitHub.

## Lesson Modules

[Git Branches](modules/branches.ipynb)

## Additional Materials

- [Try Git - Basic Syntax practice](https://try.github.io/levels/1/challenges/1)
- [Command Line and Git/GitHub Cheat Sheets](https://git.generalassemb.ly/AdiBro/Resources/tree/master/Cheat-Sheets#command-line-and-git)
- [Pro Git](https://git-scm.com/book/en/v2)
- [Git and GitHub Resources](https://git.generalassemb.ly/AdiBro/Resources/blob/master/Enviroment.md#git-and-github)
