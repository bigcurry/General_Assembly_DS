### v1.1 | 04.10.17

_Editor: Sam Stack_

- Copy edit updates from claire's branch

- Q12: replaced 'my name' with 'kiefer'.

- added to GitIgnore '.DS_Store' 

- changed 'ipynb_checkpoints' to '*.ipynb_checkpoints' in git ignore.


### v1.0 | 02.27.17

_Editor: Kiefer Katovich_

- Formatted notebook for DSI v2

---

### v0.0

_Author: Kiefer Katovich_
