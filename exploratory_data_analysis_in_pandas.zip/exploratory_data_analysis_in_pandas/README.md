# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) Exploratory Data Analysis in Pandas

## Student Requirements

Before this lesson, you should be familiar with basic Python syntax.

## Learning Objectives

After this lesson, you should be able to...

- Explain the purpose of Pandas
- Select columns and filter rows in Pandas DataFrames.
- Manipulate Pandas DataFrames by sorting rows, modifying columns, handling missing values, aggregating by groups, and applying functions.
- Describe options for handling missing data
- Work with multiple Pandas DataFrames by concatenating and joining them.

## Lesson Modules

- [Inspecting Data](./modules/inspecting_data.ipynb)
- [Manipulating Data](./modules/manipulating_data.ipynb)
- [Joining Data](./modules/joining_data.ipynb)

## Recordings

- [Mar 31, 2020](https://generalassembly.zoom.us/rec/share/uJdPKrvs0FhJHdbRzX3ucI5_IYXbT6a8gyYWqPMJmExjss57qpnCjpJaPa3PF4zp)
- [Apr 2, 2020](https://generalassembly.zoom.us/rec/share/vs95cb_8-FFJT6eW2hrTXYoBIt_Veaa8gyQW_fNfyhn1cBP1jPUa4USXl5o-7VAI)
- [Apr 7, 2020](https://generalassembly.zoom.us/rec/share/9J1baKP73ThOUpHQ-kvYY7MPAb7dT6a813AfrPZby03CT0DML7Uw6-JpMClzXIHq)

## Next Steps

Identify a dataset that you might want to use for your final project, load it into a Pandas DataFrame, and explore it using the techniques from this lesson.

## Additional Resources

### Pandas

#### General

- [Minimally Sufficient Pandas](https://medium.com/dunder-data/minimally-sufficient-pandas-a8e67f2a2428)
- [Another EDA Tutorial](https://www.datacamp.com/community/tutorials/exploratory-data-analysis-python#gs.T3TSKbk)
- [Learn a new pandas trick every day!](https://www.dataschool.io/python-pandas-tips-and-tricks/)
- [Pandas cheat sheet](https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf)
- [More Pandas cheat sheets](https://git.generalassemb.ly/AdiBro/Resources/tree/master/Cheat-Sheets#pandas)
- [List of Resources from Data School](http://www.dataschool.io/best-python-pandas-resources/)
- [More Pandas Resources](https://git.generalassemb.ly/AdiBro/Resources/blob/master/Data-Analysis-Visualization/Data-Analysis.md#pandas)

#### For Excel Users

##### Translating from Excel to Pandas

- [Intro to Pandas for Excel Super Users](https://towardsdatascience.com/intro-to-pandas-for-excel-super-users-dac1b38f12b0)
- [Excel vs Python: How to Do Common Data Analysis Tasks](https://www.dataquest.io/blog/excel-vs-python/)

##### Using Excel and Pandas Together

- [Using Python Pandas With Excel Sheet](https://medium.com/better-programming/using-python-pandas-with-excel-d5082102ca27)
- [xlwings](https://www.xlwings.org/)

#### For SQL Users

- [Pandas Comparison with SQL](https://pandas.pydata.org/pandas-docs/stable/comparison_with_sql.html)
- [Pandas equivalent of 10 useful SQL queries](https://towardsdatascience.com/pandas-equivalent-of-10-useful-sql-queries-f79428e60bd9)

### Data Analysis

- [Python for data analysis resources](https://git.generalassemb.ly/AdiBro/Resources/blob/master/Data-Analysis-Visualization/Data-Analysis.md#python-for-data-analysis)
- [Exploratory Data Analysis (EDA) resources](https://git.generalassemb.ly/AdiBro/Resources/blob/master/Data-Analysis.md#exploratory-data-analysis)

### SQL

You don't need SQL for this course, but if you are working with relational data for your final project (data spread across multiple tables that are linked by foreign keys) then you will at least need to understand how joins work.

- [The SQL Tutorial for Data Analysis](https://community.modeanalytics.com/sql/tutorial/introduction-to-sql/)
- [SQLZoo Tutorials](https://sqlzoo.net)
- [SQL Joins](https://www.w3schools.com/sql/sql_join.asp)
- [Tidy Data](https://vita.had.co.nz/papers/tidy-data.pdf)
